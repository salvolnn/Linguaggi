/** Classe Documento.
*   Classe astratta per una gerarchia di ereditarietà di documenti.
*/

import java.util.*;

public abstract class Documento {
	
	public static int counter = 1000;
	protected int id;
	
	/** Metodo che restituisce l'identificativo del documento. 
	* @return l'id del documento.
	*/
	public int getId () {
		return id;
	}
		
	/** Metodo che restituisce una descrizione del tipo di documento, ad es. "Libro". 
	* @return l'informazione sul documento.
	*/
	abstract public String getInfo ();
}