/** Classe Autore. */

import java.util.*;

public class Autore {

	public String nome;
	public String cognome;
	
	/** Costruttore senza parametri. Usa uno scanner per chiedere
	*   all'utente di inserire i dati.
	*/
	public Autore (){
  	  	Scanner user_input = new Scanner ( System.in );
  	  	System.out.print ( "\tDigita il cognome dell'autore: " );
  		this.cognome = user_input.nextLine ();
  		System.out.print ( "\tDigita il nome dell'autore: " );
  		this.nome = user_input.nextLine ();
	}
	
	public String toString () { 
        return 
        this.nome + " " + this.cognome;
    }
}
