import java.util.*;

public class Dizionario extends Documento{

	protected Autore[] autori;
	protected String casaEditrice;
	protected String lingua;
	
	public Dizionario () {
		this.id = ++counter;
	  	System.out.println ( "Inserimento di un nuovo dizionario" );	
  	  	Scanner usr_str = new Scanner ( System.in );
  	  	Scanner in_aut = new Scanner ( System.in );
  	  	System.out.println( "Inserisci il numero di autori" );
  	  	autori = new Autore[ in_aut.nextInt() ];
  	  	for ( int i = 0 ; i < autori.length ; i++ ) {
  	  		System.out.printf ( "Inserimento dell'autore %d\n", i+1 );	
  			this.autori[i] = new Autore ();
  	  	}
  	  	System.out.print ( "Digita la lingua del dizionario: " );
  		this.lingua = usr_str.nextLine ();
  		System.out.print ( "Digita la casa editrice del libro: " );
  		this.casaEditrice = usr_str.nextLine ();
	}
	
	public String toString () { 
        return 
        "\nID: " + this.id + " " +
        this.getInfo() +
        "\nAutori: " + Arrays.toString ( this.autori ) + 
        "\nLingua: " + this.lingua +  
        "\nCasa editrice: " + this.casaEditrice + 
        "\n";
    }
    
    public String getInfo(){
    	return( "Tipo di documento: Dizionario" );
    }
}
