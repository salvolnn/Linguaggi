import java.util.*;

public class Libro extends Documento{

	protected Autore[] autori;
	protected String titolo;
	protected String casaEditrice;
	
	public Libro () {
		this.id = ++counter;
	  	System.out.println ( "Inserimento di un nuovo libro" );	
  	  	Scanner usr_str = new Scanner ( System.in );
  	  	Scanner in_aut = new Scanner ( System.in );
  	  	System.out.println( "Inserisci il numero di autori" );
  	  	autori = new Autore[ in_aut.nextInt() ];
  	  	for ( int i = 0 ; i < autori.length ; i++ ) {
  	  		System.out.printf ( "Inserimento dell'autore %d\n", i+1 );	
  			this.autori[i] = new Autore ();
  	  	}
  	  	System.out.print ( "Digita il titolo del libro: " );
  		this.titolo = usr_str.nextLine ();
  		System.out.print ( "Digita la casa editrice del libro: " );
  		this.casaEditrice = usr_str.nextLine ();
	}
	
	public String toString () { 
        return 
        "\nID: " + this.id + " " +
        this.getInfo() +
        "\nAutori: " + Arrays.toString ( this.autori ) + 
        "\nTitolo: "  + this.titolo +
        "\nCasa editrice: " + this.casaEditrice + 
        "\n";
    }
    
    public String getInfo(){
    	return ( "Tipo di documento: Libro" );
    }
}
