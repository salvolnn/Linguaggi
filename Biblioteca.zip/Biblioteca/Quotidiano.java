import java.util.*;

public class Quotidiano extends Documento{

	protected String titolo;
	protected String data;
	
	public Quotidiano () {
		this.id = ++counter;
	  	System.out.println ( "Inserimento di un nuovo quotidiano" );	
  	  	Scanner usr_str = new Scanner ( System.in );

  	  	System.out.print ( "Digita il nome del quotidiano: " );
  		this.titolo = usr_str.nextLine ();
  		System.out.print ( "Digita la data del quotidiano: " );
  		this.data = usr_str.nextLine ();
	}
	
	public String toString () { 
        return 
        "\nID: " + this.id + " " +
        this.getInfo() +
        "\nTitolo: " + "\"" + this.titolo + "\"" + 
        "\nData: " + this.data + 
        "\n";
    }
    
    public String getInfo(){
    	return ( "Tipo di documento: Quotidiano" );
    }
}
