import java.util.*;

public class LibroPrestabile extends Libro implements Prestabile {

	protected String nome;
	protected String dataPrestito;
	protected String dataRestituzione;
	public boolean inPrestito;
	
	public void settaNome (String nome) {
		this.nome = nome;
	}
	
	public void settaDataPrestito (String dataPrestito) {
		this.dataPrestito = dataPrestito;
	}

	public void settaDataRestituzione (String dataRestituzione) {
		this.dataRestituzione = dataRestituzione;
	}
	
	public void prestito () {
		Scanner in = new Scanner ( System.in );
  	  	System.out.print ( "Digita il nome dell'utente: " );
  		this.settaNome ( in.nextLine () );
  		System.out.print ( "Digita la data del prestito: " );
  		this.settaDataPrestito ( in.nextLine () );
  		System.out.print ( "Digita la data di restituzione: " );
  		this.settaDataRestituzione ( in.nextLine () );
  		this.inPrestito = true;
	}
	
	public void restituzione () {
		this.inPrestito = false;
	}
	
	public LibroPrestabile() {
		super();
	}
	
	public String toString () {
		if ( this.inPrestito ) 
			return super.toString() + "Prestato a: " + this.nome 
			+ " il: " + this.dataPrestito + " fino al: " + this.dataRestituzione;
		else return super.toString();
	}
	
	public String getInfo(){
    	return ( "Tipo di documento: Libro (disponibile al prestito)" );
    }
}
