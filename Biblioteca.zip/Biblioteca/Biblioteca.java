/** Classe Biblioteca. Permette di costruire e gestire una semplice biblioteca. */

import java.util.*;

public class Biblioteca {

	private String nomeBiblioteca;
	ArrayList<Documento> archivio = new ArrayList<Documento>();
	
	public Biblioteca (){
  	  	Scanner in = new Scanner ( System.in );
  	  	System.out.println( "\tInserisci il nome delle Biblioteca" );
  		this.nomeBiblioteca = in.nextLine ();
	}
	
	public void ricerca ( String chiave ) {
		int count = 0;
		for ( int i = 0 ; i < this.archivio.size() ; i++ ){
			if ( this.archivio.get(i) instanceof Libro ) {
				Libro l = (Libro) this.archivio.get(i);
				for ( int j = 0 ; j < l.autori.length ; j++ ){
				String cognomeCorrente = l.autori[j].cognome;
					if ( chiave.trim().equalsIgnoreCase(cognomeCorrente) ) {
					System.out.println ( l );
					count++;
					}
				}	
			}
			if ( this.archivio.get(i) instanceof Dizionario ) {
				Dizionario d = (Dizionario) this.archivio.get(i);
				for ( int j = 0 ; j < d.autori.length ; j++ ){
				String cognomeCorrente = d.autori[j].cognome;
					if ( chiave.trim().equalsIgnoreCase(cognomeCorrente) ) {
					System.out.println ( d );
					count++;
					}
				}	
			}
		}
		if ( count == 0 ) System.out.println ( "\tNessun risultato trovato!" );
	}
	 
	public void prestito ( String chiave ) {
		boolean trovato = false;
		for ( int i = 0 ; i < this.archivio.size() ; i++ ){
			if ( this.archivio.get(i) instanceof LibroPrestabile && String.valueOf ( this.archivio.get(i).getId()).equals(chiave) ) {
				trovato = true;
				LibroPrestabile l = (LibroPrestabile) this.archivio.get(i);
				if (l.inPrestito) 
					System.out.println ( "Il libro è già in prestito!" );
				else
					l.prestito();
			}
		}
		if ( ! trovato ) 
			System.out.println ( "l'ID specificato non corrisponde a un libro prestabile" );
	} 
	  
	public void restituzione ( String chiave ) {
		boolean trovato = false;
		for ( int i = 0 ; i < this.archivio.size() ; i++ ){
			if ( this.archivio.get(i) instanceof LibroPrestabile && String.valueOf(this.archivio.get(i).getId()).equals(chiave)) {
				trovato = true;
				LibroPrestabile l = (LibroPrestabile) this.archivio.get(i);
				if (l.inPrestito) {
					l.restituzione();
					System.out.println ( "Restituzione effettuata con successo." );
				}
				else
					System.out.println ( "Il libro non è in prestito!" );
			}
		}
		if ( ! trovato ) 
			System.out.println ( "l'ID specificato non corrisponde a un libro in prestito" );
	}   
	  	
  	public static void main ( String[] args ) {	
  	int scelta = 1;
  	String chiave;
  	Scanner in = new Scanner ( System.in );
  	Scanner in_str = new Scanner ( System.in );
  	
  	Biblioteca x = new Biblioteca () ;

  		while ( scelta != 0 ){
  			System.out.println ( "\n************** Menu " );
  			System.out.println ( "\tDigita 1 per stampare il contenuto della Biblioteca" );
  			System.out.println ( "\tDigita 2 per aggiungere un libro" );
  			System.out.println ( "\tDigita 3 per aggiungere un dizionario" );
  			System.out.println ( "\tDigita 4 per aggiungere un quotidiano" );
  			System.out.println ( "\tDigita 5 per effettuare un prestito" );
  			System.out.println ( "\tDigita 6 per effettuare una restituzione" );
  			System.out.println ( "\tDigita 7 per la ricerca per autore" );
  			System.out.println ( "\tDigita 0 uscire");
  			scelta = in.nextInt ();
  			switch ( scelta ) {
  				case 1: 
  				    System.out.println ( "\n**** Biblioteca " + x.nomeBiblioteca + " ****");
  					for ( int i = 0 ; i < x.archivio.size () ; i++ )
  						System.out.println ( x.archivio.get(i) );
  					System.out.println ( "\n**** **** **** **** **** ****");
  					break;
  				case 2: 
  					System.out.println ( "Il libro è disponibile per il prestito? (s/n)");
  					chiave = in_str.nextLine ();
  					if (chiave.equalsIgnoreCase("n")){
  						x.archivio.add( new Libro() ); break;
  					}
  					else if (chiave.equalsIgnoreCase("s")){
  						x.archivio.add( new LibroPrestabile() ); break;
  					}
  					else {
  						System.out.println ( "\tScelta non valida!" );
  						break;
  					}
  				case 3: x.archivio.add( new Dizionario() ); break;
  				case 4: x.archivio.add( new Quotidiano() ); break;
  				case 5: System.out.println ( "\tDigita l'ID del libro da prestare:" );
  					chiave = in_str.nextLine ();
  					x.prestito ( chiave );
  					break;
  				 case 6: System.out.println ( "\tDigita l'ID del libro da restituire:" );
  					chiave = in_str.nextLine ();
  					x.restituzione ( chiave );
  					break;
  				case 7: System.out.println ( "\tDigita il cognome dell'autore:" );
  					chiave = in_str.nextLine ();
  					System.out.println ( "\tHo trovato i seguenti libri di " + chiave + ":" );
  					x.ricerca (chiave);
  					break;
				case 0: System.out.println ( "Arrivederci!" ); break;
				default: System.out.println ( "Scelta non valida! Riprova." );
  			}
  		}
  	}
}