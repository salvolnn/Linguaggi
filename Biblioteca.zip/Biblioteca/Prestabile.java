/** 
* Interfaccia Prestabile. Permette ad esempio di implementare il prestito 
* di documenti in una biblioteca. 
*/

public interface Prestabile {
	/** Setta il nome dell'utente a cui viene prestato.
	@param nome il nome dell'utente. */
	public void settaNome (String nome);
	
	/** Setta la data del prestito.
	@param dataPrestito la data del prestito. */
	public void settaDataPrestito (String dataPrestito);
	
	/** Setta la data di restituzione.
	@param dataRestituzione la data di restituzione. */
	public void settaDataRestituzione (String dataRestituzione);
}
