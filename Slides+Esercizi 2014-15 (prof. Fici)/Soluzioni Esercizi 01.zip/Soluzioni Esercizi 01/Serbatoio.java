 
/** Classe Serbatoio, modella un semplice serbatoio 
 * @author      Gabriele Fici <gabriele.fici@unipa.it>
 * @version     0.2
 */
 
public class Serbatoio {

	private int livello;		         			// attributo livello del serbatoio 			
	private int capacita = 100;						// attributo capacita' del serbatoio					
  	
  	/** metodo costruttore senza parametri,
  	 *  setta il livello a 10 litri
  	 */
  	public Serbatoio (){						
  		livello = 10;
  	}
  	 
  	/** secondo metodo costruttore 
  	 *  @param l setta il livello a l litri
  	 */ 
  	public Serbatoio (int l){					
  		livello = l;
  	}
  	
  	/** terzo metodo costruttore 
  	 *  @param l setta il livello a l litri
  	 *  @param c setta la capacita' a c litri
  	 */ 
  	public Serbatoio (int l, int c){			
  		livello = l;
  		capacita = c;
  	}
  	
  	/** metodo rifornimanto 
  	 *  @param l incrementa il livello di l litri
  	 */ 
  	public void rifornimento (int l){  	
  		livello += l;
  	}
  	
  	/** metodo consumo 
  	 *  @param l decrementa il livello di l litri
  	 */ 
  	public void consumo (int l){				
  		livello -= l;
  	}
  	
  	/** metodo getLivello 
  	 *  @return livello del serbatoio
  	 */ 
  	public int getLivello (){					
  		return livello;
  	}
  	
  	public static void main(String[] args) {					
  		Serbatoio s;									// dichiarazione
  		s = new Serbatoio (); 							// istanziazione
  		/* oppure Serbatoio s = new Serbatoio (); */
  		 		
  		s.consumo (5);									// ora livello vale 5
  		s.rifornimento (10);							// ora livello vale 15
        System.out.println ( "Il livello di s è " + s.getLivello() ); 
        
        Serbatoio s1 = new Serbatoio (5, 50);			// s1 ha capienza 50 e livello 5
        
        System.out.println ( "Il livello di s1 è " + s1.livello );  
    	/* funziona perche' stiamo accedendo a un attributo privato 
        dall'interno della classe, tuttavia non e' una buona idea accedere in questo 
        modo ad un attributo privato, per questo abbiamo creato il 
        metodo pubblico getLivello(). 
        */
    }
}