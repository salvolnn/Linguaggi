// Importiamo il package java.util, che contiene la classe Scanner, per prendere input da console:
import java.util.*;

public class EserciziStringhe { 

	public static String iniziali (String nome, String cognome){
		String iniziali = nome.charAt(0) + "&" + cognome.charAt(0);
		/* oppure:
		String iniziali = nome.substring(0,1) + "&" + cognome.substring(0,1);
		*/
		return iniziali;
	}
	
	public static String stringReverse (String s){
		String rev = "";
		for ( int i = s.length() - 1 ; i >= 0 ; i-- ){
			rev = rev + s.charAt(i);
		}
		return rev;
	}
	
	public static int substringOccurrences (String pattern, String text){
		int counter = 0, pl = pattern.length(), tl = text.length();
	    for (int i = 0 ; i < tl - pl ; i++ ){
    		if ( text.substring(i, i + pl).equals(pattern) )
    			counter ++;
    	}    
    	return counter;
	}
	
	public static boolean isValidEmail (String s) {
		if ( s==null ) { 
			System.out.println("email non valida");
			return false; 
		}
		else if ( s.length()<6 ) {
			System.out.println("email troppo corta");
			return false; 
		}
		else if (s.indexOf('@') <= 0 ) {
			System.out.println("manca la chiocciola o e' il primo carattere");
			return false; 
		}
		else if ( s.indexOf('@')!=s.lastIndexOf('@') ) {
			System.out.println("piu' di una chiocciola");
			return false; 
		}
		else if ( s.indexOf('@') == s.length()-1 ) {
			System.out.println("chiocciola in posizione errata");
			return false;
		}
		else if ( s.indexOf('@') > s.lastIndexOf('.') ) {
			System.out.println("chiocciola in posizione errata");	
			return false;
		}		
		else if ( s.length()-s.lastIndexOf('.') < 2 ) {
			System.out.println("punto non seguito da due o tre caratteri");
			return false; 
		}
		else if ( s.length()-s.lastIndexOf('.') > 3 ) {
			System.out.println("punto non seguito da due o tre caratteri");
			return false; 
		}
		else if ( s.charAt(s.indexOf('@')+1)=='.' || s.charAt(s.indexOf('@')-1)=='.' ) {
			System.out.println("punto vicino a chiocciola");
			return false; 
		}
		else {
			System.out.println("email valida!");
			return true;
		}
	}
	
	public static String fibonacciWord (int n) {
		if (n==0) return "b";
		else if (n==1) return "a";
		else{
			String x="b", y="a", z="ab";
			for( int i=2; i<=n; i++ ) {
                z = y+x;
                x = y;
                y = z;
            }
			return z;   
		}
    }
	
	public static void main (String[] args){
	
	    /* Test iniziali
		Scanner user_input = new Scanner( System.in );
    	String nome, cognome;
    	System.out.print( "Digita il nome: " );
    	nome = user_input.nextLine();
    	System.out.print( "Digita il cognome: " );
    	cognome = user_input.nextLine();  
    	System.out.println( "Le iniziali sono " + iniziali(nome, cognome) );
    	*/
    	
		/* Test reverse
		Scanner user_input = new Scanner( System.in );
    	String s;
    	System.out.print( "Digita una stringa: " );
    	s = user_input.nextLine();
		System.out.println( "La reverse e': " + stringReverse(s) );
		*/
	
		/* Test substringOccurrences
		Scanner user_input = new Scanner( System.in );
    	String pattern, text;
    	System.out.print( "Digita una stringa pattern: " );
    	pattern = user_input.nextLine();
    	System.out.print( "Digita una stringa testo: " );
    	text = user_input.nextLine();  
    	System.out.println( "Ho trovato " + substringOccurrences(pattern, text) + " occorrenze" );
    	*/
    	
    	/* Test isValidEmail
    	Scanner user_input = new Scanner( System.in );
    	System.out.print( "Digita un indirizzo email: " );
    	String email = user_input.nextLine();
    	boolean b = isValidEmail(email);
    	*/
    }
}