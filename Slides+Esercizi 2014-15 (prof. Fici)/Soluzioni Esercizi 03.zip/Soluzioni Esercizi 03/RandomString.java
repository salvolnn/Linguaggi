import java.util.*;

// Programma per generare una stringa casuale 
public class RandomString { 
	
	public static void main (String[] args){
		
		if( args.length != 2 ) {
			System.out.println("Errore. Lanciare il programma con due paramteri interi!");
		}
		
		else {
			int alph_size = Integer.parseInt(args[0]);
			int len = Integer.parseInt(args[1]);
		
			String rand_string = "";
		
			for(int i=0; i<len ; i++) {
				int rand_char = (int) (Math.random()*alph_size);
				rand_string += rand_char;
			}
		
			System.out.println(rand_string);
		
		}
		
    }
}