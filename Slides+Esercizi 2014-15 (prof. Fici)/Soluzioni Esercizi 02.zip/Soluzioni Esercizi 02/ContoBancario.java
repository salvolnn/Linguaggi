/** Classe ContoBancario, modella un semplice conto bancario*/

// Importiamo il package java.util, che contiene la classe Scanner, per prendere input da console:
import java.util.*;

public class ContoBancario {

	private static int counter=0;		// contatore per numero di conto progressivo	
	private int numeroConto;			// attributo per numero di conto
	private double saldo;				// attributo per il saldo corrente
	private String nomeTitolare;		// attributo per il nome del titolare		
  	
  	public ContoBancario (){			// costruttore senza parametri
  		this.numeroConto = ++counter;
  		System.out.println( "Creazione del conto numero " + this.numeroConto );	
  	  	Scanner user_input = new Scanner( System.in );
  	  	System.out.print( "\tDigita il nome del titolare: " );
  		this.nomeTitolare = user_input.nextLine();
  	}
  	
  	public ContoBancario (double s){    // costruttore con attribuzione del saldo iniziale
  		this.numeroConto = ++counter;
  		this.saldo = s;
  		System.out.println( "Creazione del conto numero " + this.numeroConto );	
  	  	Scanner user_input = new Scanner( System.in );
  	  	System.out.print( "\tDigita il nome del titolare: " );
  		this.nomeTitolare = user_input.nextLine();
  	}
  	
	public void deposita (double valuta){					
		this.saldo += valuta;
	}
	
	public void preleva (double valuta){					
		this.saldo -= valuta;
	}
	 
	public double getSaldo (){				        	
		return this.saldo;
	}
	
	public int getNumeroConto (){
		return this.numeroConto;
	}
	
	public String getTitolare (){
		return this.nomeTitolare;
	}
	
	public void effettuaBonifico (double ammontare, ContoBancario that){
		this.preleva(ammontare);
		that.deposita(ammontare);
	}
	
	// Il metodo toString permette di stampare il contenuto di un oggetto
	public String toString() { 
        return 
        "\nConto numero: " + this.numeroConto + 
        "\nNome Titolare: " + this.nomeTitolare + 
        "\nSaldo: " + this.saldo + 
        "\n";
    }

  	
  	public static void main(String[] args) {			
		ContoBancario mioConto = new ContoBancario();	
		ContoBancario contoMamma = new ContoBancario(3500);
		contoMamma.effettuaBonifico(1500, mioConto);
		
		System.out.println ( mioConto.toString() ); 
		System.out.println ( contoMamma.toString() ); 
		}
		
    }
}