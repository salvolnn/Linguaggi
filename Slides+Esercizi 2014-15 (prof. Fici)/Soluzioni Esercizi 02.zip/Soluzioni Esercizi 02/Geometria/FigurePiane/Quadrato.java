package Geometria.FigurePiane;

public final class Quadrato  {

	private int lato;
  	
  	public Quadrato (int lato){         
		this.lato = lato;		        
  	}
  	
  	public int getLato (){   
  		return this.lato;
  	}
  	
	public int calcolaArea (){					 							
		return this.lato * this.lato;
	}
	
	public void raddoppiaLato (){
		this.lato *= 2;
	}
  	
	public String toString() {    
		return "sono un quadrato di lato " + this.lato + " e area " + this.calcolaArea();
	} 
}