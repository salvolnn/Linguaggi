package Geometria.FigurePiane;

public class ClasseProva {
	
	public static void main(String[] args) {
		Quadrato q = new Quadrato(10);
		Quadrato q2 = new Quadrato(5);
		
		System.out.println(q.toString());
		System.out.println(q2.toString());
		
		System.out.println("Area di q =" + q.calcolaArea());
		q.raddoppiaLato();
		System.out.println("Area di q =" + q.calcolaArea());
	}
}