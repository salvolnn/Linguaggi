package Geometria.FigurePiane;

/** Classe Cerchio, modella un semplice cerchio */
public class Cerchio {
	public final static double PIGRECO = 3.14159;		// attributo statico
	private double raggio;							    // attributo 
  	
  	/** Costruttore
  	 * @param r setta il raggio a r
  	 */
  	public Cerchio (double r){	 					
  		raggio = r;  		                    
  	}
  	
  	/** Metodo per calcolare l'area
  	 * @return l'area del cerchio
  	 */
	public double CalcolaArea (){						
		double area;									// variabile locale
		area = raggio*raggio*PIGRECO;									
		return(area);
	}
  	
  	public static void main(String[] args) {			
		System.out.println(Cerchio.PIGRECO);			
		/* possibile anche senza avere creato oggetti di tipo cerchio perche' PIGRECO e' static */
		
		Cerchio c = new Cerchio(8);
		System.out.println("L'area e' " + c.CalcolaArea());
    }
}